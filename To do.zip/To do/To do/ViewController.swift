//
//  ViewController.swift
//  To do
//
//  Created by Eyad on 23/05/1444 AH.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource {
  
    
    var item = [String]()
    @IBOutlet weak var tablview: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.item = UserDefaults.standard.stringArray(forKey: "item") ?? []
        view.addSubview(tablview)
        tablview.dataSource = self
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        tablview.frame = view.bounds
    }

    @IBAction func abtn(_ sender: UIBarButtonItem) {
        let al = UIAlertController(title: "Add New Item", message: "", preferredStyle: .alert)
        al.addTextField { field in
            field.placeholder = "Scold 3mk"
        }
        al.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:nil))
        al.addAction(UIAlertAction(title: "Add", style: .default, handler: {[weak self] UIAlertAction in
            if let text = al.textFields?.first{
                if !text.text!.isEmpty {
                 //   print(text.text)
                   
                    DispatchQueue.main.async {
                        var items = UserDefaults.standard.stringArray(forKey: "item") ?? []
                        items.append(text.text!)
                        UserDefaults.standard.setValue(items, forKey: "item")
                        self?.item.append(text.text!)
                        self?.tablview.reloadData()
                    }
                }
            }
        }))
        present(al,animated: true)
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return item.count
    }
  
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tablview.dequeueReusableCell(withIdentifier: "tabcell", for: indexPath)
        cell.textLabel?.text = item[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
            return true
        }
    
    func tableView(_ tableView: UITableView, commit editingStyle:   UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            if (editingStyle == .delete) {
                item.remove(at: indexPath.row)
                UserDefaults.standard.removeObject(forKey: "item")
                var items = UserDefaults.standard.stringArray(forKey: "item") ?? []
                items.append(contentsOf: item)
                UserDefaults.standard.setValue(items, forKey: "item")
                tableView.beginUpdates()
                tableView.deleteRows(at: [indexPath], with: .right)
                tableView.endUpdates()
            }
        }

}

